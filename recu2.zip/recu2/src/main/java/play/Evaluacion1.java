package play;

import ventanas.Ventana;

public class Evaluacion1 {

    public static void main(String[] args) {
        Ventana tur = new Ventana();
        tur.setVisible(true);
        tur.setLocationRelativeTo(null);
    }
}
