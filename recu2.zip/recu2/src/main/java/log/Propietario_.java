package log;

import model.Propietario;
import javax.annotation.processing.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="org.eclipse.persistence.internal.jpa.modelgen.CanonicalModelProcessor", date="2025-05-01T01:33:15", comments="EclipseLink-2.7.10.v20211216-rNA")
@StaticMetamodel(Propietario.class)
public class Propietario_ { 

    public static volatile SingularAttribute<Propietario, String> Nombre;
    public static volatile SingularAttribute<Propietario, String> Apellidos;
    public static volatile SingularAttribute<Propietario, Integer> id_propietario;
    public static volatile SingularAttribute<Propietario, String> cedula;

}